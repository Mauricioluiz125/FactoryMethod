package br.com;

public class PizzaQueijo implements Pizza {
    public String getDescription() {
		return "Pizza de queijo";
	}

}