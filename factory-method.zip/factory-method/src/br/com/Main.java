package br.com;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
	Pizza pizzaQueijo = PizzaFactory.createPizza("queijo");
	System.out.println(pizzaQueijo.getDescription());

	Pizza pizzaCalabresa = PizzaFactory.createPizza("calabresa");
	System.out.println(pizzaCalabresa.getDescription());

	Pizza pizzaFrango = PizzaFactory.createPizza("frango");
	System.out.println(pizzaFrango.getDescription());

	Pizza pizzaPortuguesa = PizzaFactory.createPizza("portuguesa");
	System.out.println(pizzaPortuguesa.getDescription());
}
}
