/**
 * 
 */
package br.com;

/**
 * @author cbgomes
 *
 */
public class PizzaFactory {

	public static Pizza createPizza(String tipo) {


		if (tipo.equals("queijo")) {

			return new PizzaQueijo();

		} else if (tipo.equals("portuguesa")) {

			return new PizzaPortuguesa();

		} else if (tipo.equals("calabresa")) {

			return new PizzaCalabresa();

		} else if (tipo.equals("frango")) {

			return new PizzaFrango();
		}
		
		return null;
	}
}




