package br.com;

public class PizzaPortuguesa implements Pizza{
    public String getDescription() {
		return "Pizza portuguesa";
	}

}
