package br.com;

    public class PizzaFrango implements Pizza {
		public String getDescription() {
			return "Pizza de frango";
		}
	
	}