package br.com;

public interface Pizza {
    String getDescription();
		
	
}
