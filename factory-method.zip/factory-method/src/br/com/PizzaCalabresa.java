package br.com;

public class PizzaCalabresa implements Pizza {
    public String getDescription() {
		return "Pizza de calabresa";
	}

}
